window.CFG = {
  APP_NAME: "مليونير كرة القدم",

  // رابط ملف الأسئلة الأونلاين (يتحدّث من GitHub بدون ما تعدّل التطبيق).
  // بعد ما ترفع المشروع على GitHub بدّل USERNAME و REPO باسم حسابك واسم المستودع.
  // طول ما فيه USERNAME هيشتغل التطبيق بالأسئلة المدمجة فقط.
  QUESTIONS_URL: "https://raw.githubusercontent.com/USERNAME/REPO/main/www/questions.json",

  // إعدادات Firebase (اختياري) لتسجيل الدخول بالإيميل الحقيقي + لوحة الأبطال + حفظ التقدم على السحابة.
  // لو سبتها null: تسجيل الدخول بيتحفظ على الجهاز فقط.
  // مثال:
  // FIREBASE: { apiKey:"...", authDomain:"xxx.firebaseapp.com", projectId:"xxx", appId:"..." }
  FIREBASE: null
};
